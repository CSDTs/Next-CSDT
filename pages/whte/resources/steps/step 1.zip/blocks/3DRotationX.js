(function () {
    return function () {
        return this._3DRotationX;
    };
}());


 //# sourceURL=3DRotationX.js